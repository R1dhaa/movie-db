using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPagesMovie.Pages
{
    public class ChooseRoleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
